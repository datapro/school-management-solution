<div class="page-title hidden-print">
          <div>
            <h1><i class="fa fa-file-text-o"></i> View Staff</h1>
          </div>
        </div>
		<div class="card">
			<div class = 'panel panel-primary ch'>
						<div class = 'panel-heading'>
					<h2 align="center">All STAFFS</h2>
				</div>
					<div class="table-responsive panel-body">
						<table class="table table-striped">
							<thead>
								<tr>
									<th style='font-weight:bold;color:#074778;'>S/N</th>
									<th style='font-weight:bold;color:#074778;'>Staff Name</th>
									<th style='font-weight:bold;color:#074778;'>Employment Date</th>
									<th style='font-weight:bold;color:#074778;'>Staff Rank</th>
									<th style='font-weight:bold;color:#074778;'>Image</th>
									<th style='font-weight:bold;color:#074778;'>ACTION</th>
								</tr>
							</thead>
																
                            <tr>
                            <td> 1</td>
                            <td>UMERI CHINI FAB</td>
                            <td> 12/12/2222</td>
                            <td> MASTER</td>
                            <td> <img src='uploads/1786.jpg' style='width:40px;'></td>
                            <td><form action='' method='POST'>
                            <input type='hidden' name='hidden_id' value='26'>
                            <input type='submit' name='del_btn' value='DELETE' class='btn btn-danger'>
                            <input type='submit' name='edit_btn' value='EDIT' class='btn btn-info'>
                            </form></td>
                            </tr>
                    <!--here showing results in the table-->
                                </table>
					</div>
				</div>
			</div>	
