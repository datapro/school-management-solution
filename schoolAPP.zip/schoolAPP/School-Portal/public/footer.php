<div class="footer container-fluid" id="footer"><br>
    <div>&nbsp;</div>
    <div class="col-xs-12 col-sm-4 col-md-4 text-left">
        <br><h5>Quick Links</h5><br>
        <p><a href="http://jobitechobosi.com/aboutus.php">About</a></p>
        <p><a href="http://jobitechobosi.com/contact.php">Contact</a></p>
        <p><a href="http://jobitechobosi.com/manager.php">Manager</a></p>
        <p><a href="http://jobitechobosi.com/contact.php">Send us a mail</a></p>
    </div>

    <div class="col-xs-12 col-sm-4 col-md-4 text-left"><br>
        <h5>Insight</h5><br>
        <p><a href="#">Microsoft Sharepoint</a></p>
        <p><a href="#">Cloud Computing</a></p>
        <p><a href="#">Inverters</a></p>
    </div>

    <div class="col-xs-12 col-sm-4 col-md-4 text-left fcolor"><br>
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <h5>Our Contact Detail</h5><hr>
                    JOHN BOSCO INSTITUTE OF TECHNOLOGY, OBOSI<br>

                    Km. 7 Onitsha - Owerri Rd., Don Bosco Avenue, Ibolo Obosi, Anambra State, Nigeria.<br>
                    Tel: (234) 806-9695-263<br>
                    Tel: (234) 803-5547-174<br>
                    Email: jobitechonitsha@gmail.com<br>
                    Facebook: facebook.com/Jobitech<br><br>
            </div>
        </div>
    </div>
</div>

<div class="footer2 container-fluid text-center"><br>
    <p>Copyright © <?php echo $year; ?> All Rights Reserved 
        &nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp; St Joseph High School, Atimaka
        <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Powered By <a href="http://www.toxaswift.com">Toxaswift</a> &nbsp;&nbsp;&nbsp;<a href="generator.php" target="_blank" style="color: #111; border: 1px solid #111;">GO</a></span>
    </p>
</div>