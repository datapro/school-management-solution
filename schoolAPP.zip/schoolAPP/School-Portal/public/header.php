<header class="container-fluid">
    <div class="row" style="background: #000033; padding: 0.2%;">
        <div class="col-md-2 col-sm-2 col-xs-3" style="color: #ffffff;">
            <?php echo "<b>Today: {$date}</b>"; ?>
        </div>
        <div class="col-md-8 col-sm-8 col-xs-6">
            &nbsp;
        </div>
        <div class="col-md-2 col-sm-2 col-xs-3 text-right" style="color: #ffffff; font-weight: bold;">
            <span id='clockDisplay'></span>
        </div>
    </div><br />
    <div class="row">
        <div class="col-xs-12 col-sm-3 col-md-2 text-center">
            <center><a href="index.php"><img src="img/logo.png" class="img-responsive"></a></center>
        </div>

        <div class="col-xs-12 col-sm-7 col-md-8 text-center">
            <!--<p class="logo_txt">ST JOSEPH SCHOOL</p>-->
            <center><img src="img/head.png" class="img-responsive" /></center>
            <p class="tag_name" style="margin-top: -2%; font-size: 20px;"><b>Atimaka Yala-Nkum, Ikom. Cross River State</b></p>
        </div>

        <div class="col-xs-0 col-sm-0 col-md-2 text-right">
            &nbsp;
        </div>
    </div>
    <br />
</header>