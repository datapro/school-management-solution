<?php
	//////////Establishing Database connection
	$server = "localhost";
	$username = "aghighs2_sms";
	$password = "emmanuel02A@datapro";
	$dbname = "aghighs2_sms";
	
	$connection = mysqli_connect($server, $username, $password, $dbname);
	
	if(!$connection){
		die("Awaiting Resources");
	}
?>