# School-Portal-Kit----Version-1.0.2
New Version of School Management Software with more Modules -- Built with  PHP

<img src="/portal.PNG" />
<img src="/features.PNG" />

### Features of School Portal Kit
1. Student Registration with Unique Reg number
2. Students Result Processing and Automatic Grading
3. Student Class Attendance
4. Behavioral Analysis
5. School Fee Payment Module
6. Teachers Management
7. Online Result Checking(Scratch Card Checking can be enabled or disable)
8. Scratch Pin Generation for Different Terms

#### Usage
1. Download The project folder  into your htdocs folder(xampp users) or www folder(wamp users).
2. Create a database called spk.
3. Import the SQL file (spk.sql) into your database.
4. Open the project on your browser and click on SPK DEMO
5. Use the following login details to login as admin
Username: info@infosysitacademy.com
Password: @#godisgood

6. From here you can start exploring the portal.

To login as student, use the student Reg No and the password. This can be seen under the Student Management-> View All Students.

Enjoy your software...
